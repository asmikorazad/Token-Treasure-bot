import os
import sqlite3
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("TOKEN")
conn = sqlite3.connect("bot.db", check_same_thread=False)
cursor = conn.cursor()

# Create tables
cursor.execute("""CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    balance INTEGER DEFAULT 0,
    referred_by INTEGER
)""")
cursor.execute("""CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    link TEXT,
    reward INTEGER,
    is_active INTEGER DEFAULT 1
)""")
cursor.execute("""CREATE TABLE IF NOT EXISTS submissions (
    user_id INTEGER,
    task_id INTEGER,
    status TEXT
)""")
conn.commit()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    ref = int(context.args[0]) if context.args else None

    cursor.execute("SELECT * FROM users WHERE user_id = ?", (user.id,))
    if not cursor.fetchone():
        cursor.execute("INSERT INTO users (user_id, username, referred_by) VALUES (?, ?, ?)",
                       (user.id, user.username, ref))
        conn.commit()
        if ref and ref != user.id:
            cursor.execute("UPDATE users SET balance = balance + 5 WHERE user_id = ?", (ref,))
            conn.commit()
        await update.message.reply_text("স্বাগতম Token Treasure-এ! আপনি এখন টাস্ক কমপ্লিট করে ইনকাম করতে পারেন।")
    else:
        await update.message.reply_text("আপনি ইতিমধ্যে রেজিস্টার্ড।")

async def balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    cursor.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    await update.message.reply_text(f"আপনার ব্যালেন্স: {row[0]}")

async def refer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    bot_name = context.bot.username
    await update.message.reply_text(f"রেফার লিংক:\nhttps://t.me/{bot_name}?start={user_id}")

async def tasks(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cursor.execute("SELECT * FROM tasks WHERE is_active = 1")
    tasks = cursor.fetchall()
    if not tasks:
        await update.message.reply_text("বর্তমানে কোনো টাস্ক নেই।")
        return
    for task in tasks:
        title, link, reward = task[1], task[2], task[3]
        keyboard = InlineKeyboardMarkup([[InlineKeyboardButton("Complete Task", url=link)]])
        await update.message.reply_text(f"{title}\nরিওয়ার্ড: {reward}", reply_markup=keyboard)

async def withdraw(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("উত্তোলনের জন্য আমাদের @YourSupport বা /help-এ যোগাযোগ করুন।")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("/start [ref_id] – শুরু করুন\n/balance – ব্যালেন্স দেখুন\n/refer – রেফার লিংক\n/tasks – টাস্ক করুন\n/withdraw – উত্তোলনের জন্য\n/help – সহায়তা")

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("balance", balance))
app.add_handler(CommandHandler("refer", refer))
app.add_handler(CommandHandler("tasks", tasks))
app.add_handler(CommandHandler("withdraw", withdraw))
app.add_handler(CommandHandler("help", help_command))

print("Bot is running...")
app.run_polling()